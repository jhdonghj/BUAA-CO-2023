zip P7.zip `find -name '*.v'`
