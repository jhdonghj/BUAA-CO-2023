code-gen.py：生成包含add,sub,lui,ori,lw,sw,beq的mips代码

signed2unsigned.py：将mips代码中add/sub替换为addu/subu，方便P3测试